const AboutUs = () => {
    return (<div className="w-full mt-0 md:mt-16 pb-4 ">
        <div className="w-full md:w-[940px] min-h-screen justify-start md:justify-between mx-auto flex flex-col md:flex-row ">

        </div>
    </div>);
}

export default AboutUs;